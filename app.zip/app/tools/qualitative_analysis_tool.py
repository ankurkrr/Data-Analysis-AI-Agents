"""
app/tools/qualitative_analysis_tool.py - Fixed version without decorator
"""

from typing import List, Dict, Any
import os
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

EMBED_MODEL = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")


class QualitativeAnalysisTool:
    """
    RAG-based qualitative analysis tool for earnings call transcripts.
    Uses sentence-transformers for embeddings and FAISS for vector search.
    """
    
    def __init__(self, embed_model_name: str = EMBED_MODEL):
        """Initialize the tool with an embedding model"""
        self.embedder = SentenceTransformer(embed_model_name)
        self.index = None
        self.chunks = []
    
    def _chunk_text(self, text: str, chunk_words: int = 300) -> List[str]:
        """
        Split text into chunks of approximately chunk_words length.
        
        Args:
            text: Input text to chunk
            chunk_words: Target number of words per chunk
            
        Returns:
            List of text chunks
        """
        words = text.split()
        chunks = []
        for i in range(0, len(words), chunk_words):
            chunk = " ".join(words[i:i + chunk_words])
            if chunk.strip():
                chunks.append(chunk)
        return chunks
    
    def index_transcripts(self, transcripts: List[Dict[str, Any]]) -> bool:
        """
        Build FAISS index from transcript documents.
        
        Args:
            transcripts: List of dicts with 'name' and 'local_path' keys
            
        Returns:
            True if successful, False otherwise
        """
        self.chunks = []
        texts = []
        
        for transcript in transcripts:
            path = transcript.get("local_path")
            if not path:
                continue
                
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    text = f.read()
            except Exception:
                continue
            
            # Chunk the transcript
            chunks = self._chunk_text(text, chunk_words=300)
            
            for i, chunk in enumerate(chunks):
                meta = {
                    "source": transcript.get("name", "unknown"),
                    "chunk_id": f"{transcript.get('name', 'unknown')}_chunk_{i}"
                }
                self.chunks.append({"meta": meta, "text": chunk})
                texts.append(chunk)
        
        if not texts:
            return False
        
        # Generate embeddings
        try:
            embeddings = self.embedder.encode(texts, show_progress_bar=False)
            
            # Build FAISS index
            dimension = embeddings.shape[1]
            self.index = faiss.IndexFlatL2(dimension)
            self.index.add(np.array(embeddings).astype('float32'))
            
            return True
        except Exception:
            return False
    
    def retrieve(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        Retrieve top-k most relevant chunks for a query.
        
        Args:
            query: Search query
            top_k: Number of results to return
            
        Returns:
            List of dicts with chunk_id, source, text, and score
        """
        if self.index is None or not self.chunks:
            return []
        
        try:
            # Encode query
            query_embedding = self.embedder.encode([query])
            
            # Search
            distances, indices = self.index.search(
                np.array(query_embedding).astype('float32'), 
                min(top_k, len(self.chunks))
            )
            
            results = []
            for idx, distance in zip(indices[0], distances[0]):
                if idx < len(self.chunks):
                    chunk = self.chunks[idx]
                    results.append({
                        "chunk_id": chunk["meta"]["chunk_id"],
                        "source": chunk["meta"]["source"],
                        "text": chunk["text"][:600],  # Truncate for readability
                        "score": float(distance)
                    })
            
            return results
        except Exception:
            return []
    
    def analyze(self, transcripts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Main analysis method: indexes transcripts and extracts insights.
        
        Args:
            transcripts: List of transcript dicts with 'name' and 'local_path'
            
        Returns:
            Dict with themes, sentiment, forward_guidance, and risks
        """
        # Index the transcripts
        success = self.index_transcripts(transcripts)
        
        if not success:
            return {
                "tool": "QualitativeAnalysisTool",
                "themes": [],
                "management_sentiment": {
                    "score": 0.0,
                    "summary": "insufficient_data"
                },
                "forward_guidance": [],
                "risks": []
            }
        
        # Define search queries for different themes
        theme_queries = {
            "demand": "demand, growth, digital transformation, revenue growth, market demand",
            "attrition": "attrition, employee turnover, resignations, hiring, talent, retention",
            "guidance": "guidance, outlook, expect, forecast, projection, next quarter",
            "margins": "margin, profitability, costs, efficiency, operating margin",
            "deals": "deals, pipeline, bookings, wins, contracts, clients"
        }
        
        # Retrieve chunks for each theme
        themes = []
        for theme_name, query in theme_queries.items():
            results = self.retrieve(query, top_k=5)
            if results:
                themes.append({
                    "theme": theme_name,
                    "count": len(results),
                    "examples": results[:3]  # Top 3 examples
                })
        
        # Basic sentiment analysis (rule-based)
        sentiment_score = 0.0
        sentiment_summary = "neutral"
        
        # Positive indicators
        positive_queries = ["strong performance", "growth", "optimistic", "positive"]
        negative_queries = ["challenges", "headwinds", "concerns", "pressure"]
        
        positive_count = 0
        negative_count = 0
        
        for query in positive_queries:
            results = self.retrieve(query, top_k=3)
            positive_count += len(results)
        
        for query in negative_queries:
            results = self.retrieve(query, top_k=3)
            negative_count += len(results)
        
        # Calculate sentiment
        if positive_count > negative_count:
            sentiment_score = min(0.8, positive_count / max(positive_count + negative_count, 1))
            sentiment_summary = "positive" if sentiment_score > 0.6 else "cautiously optimistic"
        elif negative_count > positive_count:
            sentiment_score = -min(0.8, negative_count / max(positive_count + negative_count, 1))
            sentiment_summary = "negative" if sentiment_score < -0.6 else "cautious"
        else:
            sentiment_score = 0.0
            sentiment_summary = "neutral"
        
        # Extract forward guidance
        forward_guidance_results = self.retrieve(
            "guidance, outlook, expect, forecast, next quarter, full year", 
            top_k=5
        )
        
        # Identify risks
        risks = []
        risk_themes = ["attrition", "competition", "macro", "regulation"]
        for theme_name in risk_themes:
            theme_data = next((t for t in themes if t["theme"] == theme_name), None)
            if theme_data and theme_data["count"] > 0:
                risks.append({
                    "name": theme_name,
                    "evidence": [ex["chunk_id"] for ex in theme_data["examples"]]
                })
        
        return {
            "tool": "QualitativeAnalysisTool",
            "themes": themes,
            "management_sentiment": {
                "score": sentiment_score,
                "summary": sentiment_summary
            },
            "forward_guidance": forward_guidance_results,
            "risks": risks
        }