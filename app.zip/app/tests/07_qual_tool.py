# tests/07_qual_tool.py
from app.tools.qualitative_analysis_tool import QualitativeAnalysisTool
# create two small transcript files under tests/data/ if not present
transcripts = [{"name":"t1","local_path":"tests/data/sample_transcript_q1.txt"}]
tool = QualitativeAnalysisTool()
ok = tool.index_transcripts(transcripts)
print("index built:", ok)
if ok:
    res = tool.retrieve("demand", top_k=3)
    print("retrieve:", res)
    an = tool.analyze(transcripts)
    import json; print(json.dumps(an, indent=2))
