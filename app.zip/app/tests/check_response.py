"""
check_response.py - Analyze the actual API response
"""
import json
import glob

# Find the most recent test output
files = glob.glob("test_output_*.json")
if not files:
    print("No test output files found")
    exit(1)

latest = max(files)
print(f"Analyzing: {latest}")
print("=" * 60)

with open(latest, 'r') as f:
    data = json.load(f)

print("\nTop-level keys:")
for key in data.keys():
    print(f"  - {key}")

print("\nFull structure (first 100 lines):")
output = json.dumps(data, indent=2)
lines = output.split('\n')
for i, line in enumerate(lines[:100]):
    print(line)
    if i == 99 and len(lines) > 100:
        print(f"\n... ({len(lines) - 100} more lines)")

# Check for error
if 'error' in data:
    print("\n" + "=" * 60)
    print("ERROR DETECTED:")
    print("=" * 60)
    print(f"Error type: {data.get('error')}")
    print(f"Message: {data.get('message', 'No message')}")
    
    if 'synthesis' in data and isinstance(data['synthesis'], dict):
        if 'error' in data['synthesis']:
            print(f"\nSynthesis error: {data['synthesis'].get('error')}")
            print(f"Details: {data['synthesis'].get('last_exc')}")
    
    if 'synthesis_attempts' in data:
        print(f"\nSynthesis attempts: {len(data['synthesis_attempts'])}")
        for i, attempt in enumerate(data['synthesis_attempts'], 1):
            print(f"\n  Attempt {i}:")
            print(f"    Raw output (first 200 chars): {attempt.get('raw', '')[:200]}")