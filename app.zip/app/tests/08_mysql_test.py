# tests/08_mysql_test.py
from dotenv import load_dotenv
load_dotenv()
from app.db.mysql_client import MySQLClient
db = MySQLClient()
print("Connected. creating test entry.")
uid = "test-uid-1"
db.log_request(uid, {"test":"payload"})
res = db.get_result(uid)
print("Result fetch (may be None):", res)
