# app/llm/openrouter_llm.py
from langchain.llms.base import LLM
from typing import Any, List, Optional
import requests
import os
from pydantic import Field

class OpenRouterLLM(LLM):
    """Custom LLM wrapper for OpenRouter free models"""

    openrouter_api_key: str = Field(default_factory=lambda: os.getenv("OPENROUTER_API_KEY"))
    model: str = Field(default="deepseek/deepseek-chat-v3.1:free")
    base_url: str = Field(default="https://openrouter.ai/api/v1/chat/completions")

    @property
    def _llm_type(self) -> str:
        return "openrouter"

    def _call(self, prompt: str, stop: Optional[List[str]] = None) -> str:
        """Send user prompt to OpenRouter model"""
        if not self.openrouter_api_key:
            raise ValueError("Missing OpenRouter API key. Set OPENROUTER_API_KEY in your environment.")

        headers = {
            "Authorization": f"Bearer {self.openrouter_api_key}",
            "Content-Type": "application/json",
        }

        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
        }

        response = requests.post(self.base_url, headers=headers, json=payload)

        if response.status_code != 200:
            raise ValueError(f"OpenRouter API Error: {response.status_code} - {response.text}")

        data = response.json()
        return data["choices"][0]["message"]["content"]
