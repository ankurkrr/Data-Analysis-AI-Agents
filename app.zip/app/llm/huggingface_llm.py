# app/llm/huggingface_llm.py
"""
Free LLM implementation using HuggingFace Inference API
Supports multiple free models with automatic fallback
"""
from langchain.llms.base import LLM
from langchain_community.chat_models import ChatHuggingFace
from langchain_community.llms import HuggingFaceHub
from typing import Any, List, Optional
import os
from pydantic import Field
import time


class HuggingFaceLLM(LLM):
    """
    Custom LLM wrapper for HuggingFace free models with rate limit handling
    """
    
    huggingface_api_key: str = Field(default_factory=lambda: os.getenv("HUGGINGFACE_API_KEY"))
    
    # List of free models to try (in order of preference)
    models: List[str] = Field(default=[
        "mistralai/Mistral-7B-Instruct-v0.2",
        "meta-llama/Llama-2-7b-chat-hf",
        "google/flan-t5-xxl",
        "tiiuae/falcon-7b-instruct",
        "HuggingFaceH4/zephyr-7b-beta"
    ])
    
    current_model_index: int = Field(default=0)
    max_retries: int = Field(default=3)
    retry_delay: int = Field(default=5)
    
    temperature: float = Field(default=0.7)
    max_tokens: int = Field(default=2048)

    @property
    def _llm_type(self) -> str:
        return "huggingface"

    def _call(self, prompt: str, stop: Optional[List[str]] = None) -> str:
        """
        Send prompt to HuggingFace model with automatic retry and fallback
        """
        if not self.huggingface_api_key:
            raise ValueError(
                "Missing HuggingFace API key. Get free key at https://huggingface.co/settings/tokens\n"
                "Set HUGGINGFACE_API_KEY in your .env file"
            )
        
        for attempt in range(self.max_retries):
            try:
                # Get current model
                model_name = self.models[self.current_model_index]
                
                # Create HuggingFace Hub LLM
                llm = HuggingFaceHub(
                    repo_id=model_name,
                    huggingfacehub_api_token=self.huggingface_api_key,
                    model_kwargs={
                        "temperature": self.temperature,
                        "max_new_tokens": self.max_tokens,
                        "return_full_text": False
                    }
                )
                
                # Call the model
                response = llm(prompt)
                return response
                
            except Exception as e:
                error_msg = str(e).lower()
                
                # Check if it's a rate limit error
                if "rate limit" in error_msg or "429" in error_msg:
                    print(f"⚠️  Rate limit hit for {self.models[self.current_model_index]}")
                    
                    # Try next model
                    if self.current_model_index < len(self.models) - 1:
                        self.current_model_index += 1
                        print(f"🔄 Switching to model: {self.models[self.current_model_index]}")
                        continue
                    else:
                        # All models exhausted, wait and retry from first model
                        print(f"⏳ All models rate-limited. Waiting {self.retry_delay}s...")
                        time.sleep(self.retry_delay)
                        self.current_model_index = 0
                        continue
                
                # Check if model doesn't exist or auth error
                elif "not found" in error_msg or "401" in error_msg or "403" in error_msg:
                    print(f"❌ Model {self.models[self.current_model_index]} unavailable: {e}")
                    
                    # Try next model
                    if self.current_model_index < len(self.models) - 1:
                        self.current_model_index += 1
                        print(f"🔄 Trying next model: {self.models[self.current_model_index]}")
                        continue
                    else:
                        raise ValueError(f"All models failed. Last error: {e}")
                
                # Other errors
                else:
                    if attempt < self.max_retries - 1:
                        print(f"⚠️  Error (attempt {attempt + 1}/{self.max_retries}): {e}")
                        time.sleep(self.retry_delay)
                        continue
                    else:
                        raise ValueError(f"HuggingFace API Error after {self.max_retries} attempts: {e}")
        
        raise ValueError("Max retries exceeded for all models")


class HuggingFaceChatLLM(LLM):
    """
    Alternative: Using ChatHuggingFace for better instruction following
    """
    
    huggingface_api_key: str = Field(default_factory=lambda: os.getenv("HUGGINGFACE_API_KEY"))
    model_name: str = Field(default="HuggingFaceH4/zephyr-7b-beta")
    temperature: float = Field(default=0.7)
    max_tokens: int = Field(default=2048)

    @property
    def _llm_type(self) -> str:
        return "huggingface_chat"

    def _call(self, prompt: str, stop: Optional[List[str]] = None) -> str:
        """Use ChatHuggingFace wrapper for better performance"""
        if not self.huggingface_api_key:
            raise ValueError(
                "Missing HuggingFace API key. Get free key at https://huggingface.co/settings/tokens\n"
                "Set HUGGINGFACE_API_KEY in your .env file"
            )
        
        try:
            # Create base LLM
            base_llm = HuggingFaceHub(
                repo_id=self.model_name,
                huggingfacehub_api_token=self.huggingface_api_key,
                model_kwargs={
                    "temperature": self.temperature,
                    "max_new_tokens": self.max_tokens
                }
            )
            
            # Wrap with ChatHuggingFace for better instruction following
            chat_llm = ChatHuggingFace(llm=base_llm)
            
            # Format as chat message
            from langchain.schema import HumanMessage
            messages = [HumanMessage(content=prompt)]
            
            response = chat_llm(messages)
            return response.content
            
        except Exception as e:
            raise ValueError(f"HuggingFace Chat API Error: {e}")


# Simple wrapper for easy switching
def create_free_llm(provider: str = "huggingface") -> LLM:
    """
    Factory function to create a free LLM instance
    
    Args:
        provider: "huggingface" or "huggingface_chat"
    
    Returns:
        LLM instance
    """
    if provider == "huggingface_chat":
        return HuggingFaceChatLLM()
    else:
        return HuggingFaceLLM()