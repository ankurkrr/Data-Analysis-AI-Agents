from langchain_huggingface import HuggingFaceEndpoint



llm = HuggingFaceEndpoint(
    repo_id="microsoft/Phi-3-mini-4k-instruct",
    huggingfacehub_api_token="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",
    temperature=0.3,
)

response = llm.invoke("Write a one-line forecast for TCS revenue growth next quarter.")
print(response)